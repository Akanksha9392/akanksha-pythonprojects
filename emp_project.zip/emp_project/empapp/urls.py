from django.urls import path
from .views import show,fulldetail,updateemployee,deleteemployee,searchbar

urlpatterns = [
    path('', show, name='show'),  
    path('',show,name='home'),
    path('update/<int:pk>/',updateemployee,name="update"),
    path('fulldetail/<int:pk>/',fulldetail, name='fulldetail'),
    path('delete/<int:pk>/',deleteemployee,name='delete'),
    path('search/',searchbar,name='search')
]
