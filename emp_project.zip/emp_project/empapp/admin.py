from django.contrib import admin
from .models import employeeinfo,salary,leaves,ptamount,processedsalary
#Admin for employee.
class employeeinfoAdmin(admin.ModelAdmin):
    list_display=('id','eid','ename','dept','address','phone','email','experience','education')
    search_fields=('name','eid','dept','email')
    list_filter=('dept','education')
#Admin for salary.
class salaryAdmin(admin.ModelAdmin):
    list_display=('eid','jan_sal','feb_sal','mar_sal','apr_sal','may_sal','jun_sal','jul_sal','aug_sal','sep_sal','oct_sal','nov_sal','dec_sal','total_sal')
    search_fields=('eid',)
    list_filter=('eid',)
    
#Admin for leaves
class leavesAdmin(admin.ModelAdmin):
    list_display=('eid','jan_lea','feb_lea','mar_lea','apr_lea','may_lea','jun_lea','jul_lea','aug_lea','sep_lea','oct_lea','nov_lea','dec_lea','total_lea')
    search_fields=('eid',)
    list_filter=('eid',)
#Admin for ptamount
class ptamountAdmin(admin.ModelAdmin):
    list_display=('eid','jan_pt','feb_pt','mar_pt','apr_pt','may_pt','jun_pt','jul_pt','aug_pt','sep_pt','oct_pt','nov_pt','dec_pt','total_pt')
    search_fields=('eid',)
    list_filter=('eid',)
class processedsalaryAdmin(admin.ModelAdmin):
    list_display=('eid','jan_ps','feb_ps','mar_ps','apr_ps','may_ps','jun_ps','jul_ps','aug_ps','sep_ps','oct_ps','nov_ps','dec_ps','calculate_processed_salary')
    search_fields=('eid',)
    list_filter=('eid',)

#Registering models with adminpanel
admin.site.register(employeeinfo,employeeinfoAdmin)
admin.site.register(salary,salaryAdmin)
admin.site.register(leaves,leavesAdmin)
admin.site.register(ptamount,ptamountAdmin)
admin.site.register(processedsalary,processedsalaryAdmin)