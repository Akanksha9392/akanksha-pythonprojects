from django.db import models

# Create your models here.
class employeeinfo(models.Model):
    ename = models.CharField(max_length=100)
    eid = models.IntegerField(unique=True)
    phone = models.CharField(max_length=20)
    email = models.EmailField()
    dept = models.CharField(max_length=100)
    address = models.CharField(max_length=25)
    experience = models.CharField(max_length=50)
    education = models.CharField(max_length=100)

    def __str__(self):
        return self.ename



class salary(models.Model):
    eid = models.ForeignKey(employeeinfo, on_delete=models.CASCADE)
    jan_sal = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    feb_sal = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    mar_sal = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    apr_sal = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    may_sal = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    jun_sal = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    jul_sal = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    aug_sal = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    sep_sal = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    oct_sal = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    nov_sal = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    dec_sal = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    def total_sal(self):
        return (
            self.jan_sal + self.feb_sal + self.mar_sal + self.apr_sal +
            self.may_sal + self.jun_sal + self.jul_sal + self.aug_sal +
            self.sep_sal + self.oct_sal + self.nov_sal + self.dec_sal
        )

class leaves(models.Model):
    eid = models.ForeignKey(employeeinfo, on_delete=models.CASCADE)
    jan_lea = models.IntegerField(default=0)
    feb_lea = models.IntegerField(default=0)
    mar_lea = models.IntegerField(default=0)
    apr_lea = models.IntegerField(default=0)
    may_lea = models.IntegerField(default=0)
    jun_lea = models.IntegerField(default=0)
    jul_lea = models.IntegerField(default=0)
    aug_lea = models.IntegerField(default=0)
    sep_lea = models.IntegerField(default=0)
    oct_lea = models.IntegerField(default=0)
    nov_lea = models.IntegerField(default=0)
    dec_lea = models.IntegerField(default=0)
    

    def total_lea(self):
        return (
            self.jan_lea + self.feb_lea + self.mar_lea + self.apr_lea +
            self.may_lea + self.jun_lea + self.jul_lea + self.aug_lea +
            self.sep_lea + self.oct_lea + self.nov_lea + self.dec_lea
        )


class ptamount(models.Model):
    eid = models.ForeignKey(employeeinfo, on_delete=models.CASCADE)
    jan_pt = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    feb_pt = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    mar_pt = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    apr_pt = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    may_pt = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    jun_pt = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    jul_pt = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    aug_pt = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    sep_pt = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    oct_pt = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    nov_pt = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    dec_pt = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    def total_pt(self):
        return (
            self.jan_pt + self.feb_pt + self.mar_pt + self.apr_pt +
            self.may_pt + self.jun_pt + self.jul_pt + self.aug_pt +
            self.sep_pt + self.oct_pt + self.nov_pt + self.dec_pt
        )

    
class processedsalary(models.Model):
    eid = models.ForeignKey(employeeinfo, on_delete=models.CASCADE)
    jan_ps = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    feb_ps = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    mar_ps = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    apr_ps = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    may_ps = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    jun_ps = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    jul_ps = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    aug_ps = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    sep_ps = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    oct_ps = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    nov_ps = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    dec_ps = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total_ps = models.FloatField(default=0)
  
    
    def calculate_processed_salary(self):
        try:
            Salary = salary.objects.get(eid=self.eid)
            Leaves = leaves.objects.get(eid=self.eid)
            Pt = ptamount.objects.get(eid=self.eid)
        except (salary.DoesNotExist, leaves.DoesNotExist, ptamount.DoesNotExist):
            return  # Skip calculation if any data is missing

        working_days = {
            'jan': 31, 'feb': 28, 'mar': 31, 'apr': 30, 'may': 31, 'jun': 30,
            'jul': 31, 'aug': 31, 'sep': 30, 'oct': 31, 'nov': 30, 'dec': 31,
        }

        total = 0
        for month, days in working_days.items():
            sal = getattr(Salary, f"{month}_sal")
            leave = getattr(Leaves, f"{month}_lea")
            pt = getattr(Pt, f"{month}_pt")

            processed = sal - (sal * leave / days) - pt
            setattr(self, f"{month}_ps", round(processed, 2))
            total += round(processed, 2)

        self.total_ps = total

    def save(self, *args, **kwargs):
        self.calculate_processed_salary()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Processed Salary for {self.eid.ename} ({self.eid.eid})"



