from django.shortcuts import render,redirect,get_object_or_404
from .models import employeeinfo,salary,leaves,ptamount,processedsalary
from .forms import employeeForm,employeesalaryForm,leavesForm,ptamountForm
from django.core.paginator import Paginator,EmptyPage,PageNotAnInteger
def show(request):
    data = employeeinfo.objects.all()
    page_num=request.GET.get('page')
    paginator=Paginator(data,per_page=10)
    try:
        data=paginator.page(page_num)
    except PageNotAnInteger:
        data=paginator.page(1)
    except EmptyPage:
        data=paginator.page(Paginator.num_pages)
    return render(request,'show.html',{'employee1':data})


def fulldetail(request, pk):
    employee = get_object_or_404(employeeinfo, pk=pk)
    Salary = salary.objects.filter(eid=employee).first()
    Leaves = leaves.objects.filter(eid=employee).first()
    Pt_amount = ptamount.objects.filter(eid=employee).first()
    processed_salary = processedsalary.objects.filter(eid=employee).first()
    context = {
        'employee': employee,
        'salary': Salary,
        'leaves': Leaves,
        'pt_amount': Pt_amount,
        'processed_salary': processed_salary,
    }
    return render(request, 'fulldetail.html',context)

def deleteemployee(request, pk):
    data =employeeinfo.objects.get(id=pk)
    data.delete()
    return redirect('home')
def updateemployee(request, pk):
    employee = get_object_or_404(employeeinfo, pk=pk)
    salary_obj = get_object_or_404(salary, eid=employee)
    leaves_obj = get_object_or_404(leaves, eid=employee)
    pt_obj = get_object_or_404(ptamount, eid=employee)

    if request.method == 'POST':
        emp_form = employeeForm(request.POST, request.FILES, instance=employee)
        sal_form = employeesalaryForm(request.POST, instance=salary_obj)
        leaves_form = leavesForm(request.POST, instance=leaves_obj)
        pt_form = ptamountForm(request.POST, instance=pt_obj)

        if emp_form.is_valid() and sal_form.is_valid() and leaves_form.is_valid() and pt_form.is_valid():
            emp_form.save()
            sal_form.save()
            leaves_form.save()
            pt_form.save()
            ps, created = processedsalary.objects.get_or_create(eid=employee)
            ps.save()

            return redirect('home')
            # processedsalary.objects.get_or_create(eid=employee)
            # return redirect('home')  # or wherever you want to redirect
    else:
        emp_form = employeeForm(instance=employee)
        sal_form = employeesalaryForm(instance=salary_obj)
        leaves_form = leavesForm(instance=leaves_obj)
        pt_form = ptamountForm(instance=pt_obj)

    return render(request, 'update.html', {
        'emp_form': emp_form,
        'sal_form': sal_form,
        'leaves_form': leaves_form,
        'pt_form': pt_form
    })

def searchbar(request):
    if request.method=="GET":
        query=request.GET.get('query')
        if query:
            employee=employeeinfo.objects.filter(ename__contains=query)
            return render(request,'searchbar.html',{'employee':employee})
        else:
            print("No employee found to show in database")
    return render(request,'searchbar.html',{})