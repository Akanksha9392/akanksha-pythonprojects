from django import forms
from .models import employeeinfo,salary,leaves,ptamount,processedsalary
class employeeForm(forms.ModelForm):
    class Meta:
        model=employeeinfo
        fields=['ename','eid','phone','email','dept','address','email','experience','education']
        widgets={
            'ename':forms.TextInput(attrs={'class':'form-control'}),
            'eid':forms.NumberInput(attrs={'class':'form-control'}),
            'phone':forms.NumberInput(attrs={'class':'form-control'}),
            'email':forms.EmailInput(attrs={'class':'form-control'}),
            'dept':forms.TextInput(attrs={'class':'form-control'}),
            'address':forms.TextInput(attrs={'class':'form-control'}),
            'email':forms.EmailInput(attrs={'class':'form-control'}),
            'experience':forms.NumberInput(attrs={'class':'form-control'}),
            'education':forms.TextInput(attrs={'class':'form-control'}),
            }
        
class employeesalaryForm(forms.ModelForm):
    class Meta:
        model = salary
        fields = ['eid', 'jan_sal', 'feb_sal', 'mar_sal', 'apr_sal', 'may_sal', 'jun_sal',
                  'jul_sal', 'aug_sal', 'sep_sal', 'oct_sal', 'nov_sal', 'dec_sal']
        widgets = {
            'eid': forms.NumberInput(attrs={'class': 'form-control'}),
            'jan_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'feb_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'mar_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'apr_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'may_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'jun_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'jul_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'aug_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'sep_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'oct_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'nov_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'dec_sal': forms.NumberInput(attrs={'class': 'form-control'}),
        }

class leavesForm(forms.ModelForm):
    class Meta:
        model = leaves
        fields = ['eid', 'jan_lea', 'feb_lea', 'mar_lea', 'apr_lea', 'may_lea', 'jun_lea',
                  'jul_lea', 'aug_lea', 'sep_lea', 'oct_lea', 'nov_lea', 'dec_lea']
        widgets = {
            'eid': forms.NumberInput(attrs={'class': 'form-control'}),
            'jan_lea': forms.NumberInput(attrs={'class': 'form-control'}),
            'feb_lea': forms.NumberInput(attrs={'class': 'form-control'}),
            'mar_lea': forms.NumberInput(attrs={'class': 'form-control'}),
            'apr_lea': forms.NumberInput(attrs={'class': 'form-control'}),
            'may_lea': forms.NumberInput(attrs={'class': 'form-control'}),
            'jun_lea': forms.NumberInput(attrs={'class': 'form-control'}),
            'jul_lea': forms.NumberInput(attrs={'class': 'form-control'}),
            'aug_lea': forms.NumberInput(attrs={'class': 'form-control'}),
            'sep_lea': forms.NumberInput(attrs={'class': 'form-control'}),
            'oct_lea': forms.NumberInput(attrs={'class': 'form-control'}),
            'nov_lea': forms.NumberInput(attrs={'class': 'form-control'}),
            'dec_lea': forms.NumberInput(attrs={'class': 'form-control'}),
        }

class ptamountForm(forms.ModelForm):
    class Meta:
        model = ptamount
        fields = ['eid', 'jan_pt', 'feb_pt', 'mar_pt', 'apr_pt', 'may_pt', 'jun_pt',
                  'jul_pt', 'aug_pt', 'sep_pt', 'oct_pt', 'nov_pt', 'dec_pt']
        widgets = {
            'eid': forms.NumberInput(attrs={'class': 'form-control'}),
            'jan_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'feb_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'mar_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'apr_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'may_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'jun_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'jul_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'aug_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'sep_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'oct_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'nov_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'dec_pt': forms.NumberInput(attrs={'class': 'form-control'}),
        }
class psForm(forms.ModelForm):
    class Meta:
        model = processedsalary
        fields = ['eid', 'jan_ps', 'feb_ps', 'mar_ps', 'apr_ps', 'may_ps', 'jun_ps',
                  'jul_ps', 'aug_ps', 'sep_ps', 'oct_ps', 'nov_ps', 'dec_ps']
        widgets = {
            'eid': forms.NumberInput(attrs={'class': 'form-control'}),
            'jan_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'feb_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'mar_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'apr_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'may_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'jun_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'jul_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'aug_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'sep_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'oct_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'nov_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'dec_pt': forms.NumberInput(attrs={'class': 'form-control'}),
        }